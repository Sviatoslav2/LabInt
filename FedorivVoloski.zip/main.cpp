#include <fstream>
#include <iostream>
#include <thread>
#include <mutex>
#include <chrono>
#include <atomic>
#include "vector"
#include <fcntl.h>
#include <cstring>
#include <cmath>
#include <cmath>
#include <sstream>

using namespace std;

inline std::chrono::high_resolution_clock::time_point get_current_time_fenced()
{
    std::atomic_thread_fence(std::memory_order_seq_cst);
    auto res_time = std::chrono::high_resolution_clock::now();
    std::atomic_thread_fence(std::memory_order_seq_cst);
    return res_time;
}

template<class D>
inline long long to_us(const D& d)
{
    return std::chrono::duration_cast<std::chrono::microseconds>(d).count();
}
//auto stage1_start_time = get_current_time_fenced();
// To do...action
//auto stage2_start_time = get_current_time_fenced();
//auto stage1_time = stage2_start_time - stage1_start_time;

//float finish1 = to_us(stage1_time);

//std::cout<< finish1 / 1000000 <<std::endl;//It will be in seconds ==> finish1 / 1000000 ceconds.

bool print_hex = false;

const char *to_hex(char c) {
    // thise function change char to hex cod...
    int res_int = c & 0xff;

    std::stringstream s_stream;
    s_stream << std::hex << res_int;
    std::string res(s_stream.str());

    return res.c_str();
}

void read_file(char *filename, bool print_hex, long long N) {
    // filename --> Name of file
    // print_hex --> key that if it true write in consol hex cod of text. Else text.
    // N how many char you whant to read.
    int fd = open(filename, O_RDONLY);
    char buff[N];
    ssize_t bytes;

    if (fd == -1) {

        int error_num = errno;

        if (error_num == 2) {
            std::cerr << "No such file in directory." << std::endl;
        }

        std::cerr << "Error code: " << error_num << std::endl;
        exit(error_num);
    }

    while ((bytes = read(fd, &buff, N)) > 0) {

        for (int i = 0; i < bytes; ++i) {
            if (print_hex && (!(isspace(buff[i])) && !isprint(buff[i]))) {
                write(STDOUT_FILENO, to_hex(buff[i]), 1);
            } else {
                write(STDOUT_FILENO, &buff[i], 1);
            }
        }
    }
    close(fd);
}
///////////////////////////////////
///////////////////////////////////
///////////////////////////////////
///////////////////////////////////
double DeJohn(double x1 , double x2){
    double res = 0;
    for (int i = -2; i< 3; i++){
        for (double j = -2; j< 3;j++){
            double denominator = 5*(i+2) + j+3 + pow((x1 - 16*j),6) + pow((x2 - 16*i),6);
                res += 1/(int)denominator;
        }
    }
    return pow(res + 0.002,-1);
}



////////////////////////
double delta(double x1, double x2)
    {
    return x1 - x2;
    }
///////////////////////////////////////////
///////////////////////////////////////////
///////////////////////////////////////////#!
double integrate(double x1, double x2 , double y1, double y2){
    return DeJohn((x1+x2)/2,(y1+y2)/2)*delta(x2,x1)*delta(y2,y1);
}

bool ErrorCorrector (double t_abs_err, double t_rel_err,double sum,double t_sum,double abs_err, double rel_err, int i,int max_division){
    bool key = false;
    t_abs_err = fabs(t_sum - sum);
    t_rel_err = t_abs_err / fabs(t_sum);
    if (i != 0 && t_abs_err < abs_err && t_rel_err <= rel_err) {
        key = true;
    };
    if (200 * pow(2, i + 1) > max_division) {
        key = true;
    };
    return key;
}

void writeToFile(double result,char dataText[], char dataFileName[]){
    ofstream fs(dataFileName, ios_base::app | ios_base::out);
    fs << dataText <<result << endl;
}



void logic(const std::function<double(double, double)> &func_to_integrate, double &sum, double x_min, double x_max,
           double y_min, double y_max, double N, double M, std::mutex &m) {
    double temp_sum = 0;
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < M; ++j) {
            double x1 = (x_min + i * (x_max - x_min) / M),
                    x2 = (x_min + (i + 1) * (x_max - x_min) / M),
                    y1 = (y_min + j * (y_max - y_min) / N),
                    y2 = (y_min + (j + 1) * (y_max - y_min) / N);
            temp_sum += integrate(x1,x2,y1,y2);
        }
    }
    m.lock();
    sum += temp_sum;
    m.unlock();
}




void thread_pool(int NumThread, double &sum, double N1, double N2, double N, double M, std::mutex &m) {
    std::vector<std::thread> threads;
    double t_min_x = N1,
            step = (N2 - N1) / NumThread,
            t_max_x = t_min_x + step;
    for (int i = 0; i < NumThread; ++i) {
        if (i == NumThread - 1) {
            threads.emplace_back(
                    std::thread(logic, DeJohn, std::ref(sum), t_min_x, N2, N1, N2, N, M, std::ref(m)));//uses logic
        } else {
            threads.emplace_back(
                    std::thread(logic, DeJohn, std::ref(sum), t_min_x, t_max_x, N1, N2, N, M, std::ref(m)));//uses logic
        }
        if (t_max_x + step > N2)
            break;
        else {
            t_min_x = t_max_x;
            t_max_x += step;
        }
    }
    for (int i = 0; i < NumThread; ++i) {
        threads[i].join();
    }
}


double proces(int Nthreads, double result, double N1, double N2, double abs_err, double rel_err,long long init_division ){
    std::mutex mux;
    //long long init_division = 1000;
    double t_sum = 0,
            t_abs_err = 0,
            t_rel_err = 0;
    //thread_pool(int q, double &sum, double N1, double N2, double N, double M, std::mutex &m)
    double max_division = 0.00000000000000000001;
    for (int i = 0; i < 10; ++i) {
        thread_pool(Nthreads, result, N1, N2, init_division * pow(2, i), init_division * pow(2, i), mux);
        //ErrorCorrector (double t_abs_err, double t_rel_err,double sum,double t_sum,double abs_err, double rel_err, int i,int max_division){


        if (ErrorCorrector(t_abs_err, t_rel_err, result, t_sum, abs_err, rel_err, i, max_division)) {
            break;
        }
        t_sum = result;
        result = 0;
    }
    return result;
}

//////////////////////////////////#!
//////////////////////////////////#!
//////////////////////////////////#!
int main(int argc, char *argv[]) {
    //auto stage1_start_time = get_current_time_fenced();
    bool key = false;

    std::vector<std::thread> threads;

    std::vector<string> dataFromConsol;
    for(int i=0; i < argc; i++){
        dataFromConsol.emplace_back(argv[i]);
    }

    for(int i=1; i < argc; i++){
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0){
            std::cout <<"These program was prepered by Sviatoslav Fedoriv and Max Voloski \n.1 double left limit, 2 double rigte limit, 3 double step,4 double abs_err,5 double rel_err,6 int Nthreads,7 long long init_division.\n"
                    "In test regime (-t or --test)\n"
                    "            double N1 = -50.0;\n"
                    "            double N2 = 50.0;\n"
                    "            double step = 1.0/100;\n"
                    "            double abs_err = 1.0/1000;\n"
                    "            double rel_err = 1.0/1000;\n"
                    "            int Nthreads  = 4;\n"
                    "            long long init_division = 1000;"<< std::endl;
            exit(1);
        }
        else if (strcmp(argv[i], "-t") == 0 || strcmp(argv[i], "--test") == 0){
            //std::cout <<*(int*)dataFromConsol[7]<< std::endl;
            char dataFileName[] = "Data.txt";
            double result = 0;
            double N1 = -50.0;
            double N2 = 50.0;
            double step = 1.0/100;
            double abs_err = 1.0/1000;
            double rel_err = 1.0/1000;
            int Nthreads  = 4;
            long long init_division = 1000;


            auto stage1_start_time = get_current_time_fenced();


            result = proces(Nthreads, result, N1, N2, abs_err, rel_err,init_division);
            auto stage2_start_time = get_current_time_fenced();
            auto stage1_time = stage2_start_time - stage1_start_time;
            double finish1 = to_us(stage1_time);


            char data1[] = "Time == ";
            char data2[] = "Result of program == ";
            writeToFile(finish1 / 1000000, data1, dataFileName);
            writeToFile(result, data2, dataFileName);
            read_file(dataFileName, false, 2000);

        }
        else{
            key = true;
        }
    }
    if(key){
        char dataFileName[] = "Data.txt";
        double result = 0;
        double N1 = stod(dataFromConsol[1]);
        double N2 = stod(dataFromConsol[2]);
        double step = stod(dataFromConsol[3]);
        double abs_err = stod(dataFromConsol[4]);
        double rel_err = stod(dataFromConsol[5]);
        int Nthreads  = stod(dataFromConsol[6]);
        long long init_division = stol(dataFromConsol[7]);
/*
        double N1 = strtod(dataFromConsol[1], nullptr);
        double N2 = strtod(dataFromConsol[2], nullptr);
        double step = strtod(dataFromConsol[3], nullptr);
        double abs_err = strtod(dataFromConsol[4], nullptr);
        double rel_err = strtod(dataFromConsol[5], nullptr);
        int Nthreads  = strtod(dataFromConsol[6], nullptr);
        long long init_division = strtol(dataFromConsol[7], 0, 10);
*/

        auto stage1_start_time = get_current_time_fenced();

        result = proces(Nthreads, result, N1, N2, abs_err, rel_err,init_division);
        auto stage2_start_time = get_current_time_fenced();
        auto stage1_time = stage2_start_time - stage1_start_time;
        double finish1 = to_us(stage1_time);


        char data1[] = "Time == ";
        char data2[] = "Result of program == ";
        writeToFile(finish1 / 1000000, data1, dataFileName);
        writeToFile(result, data2, dataFileName);
        read_file(dataFileName, false, 2000);

    }
    return 0;

}